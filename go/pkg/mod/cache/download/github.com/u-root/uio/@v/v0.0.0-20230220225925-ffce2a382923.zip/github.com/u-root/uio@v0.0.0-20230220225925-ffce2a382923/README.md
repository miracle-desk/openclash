# uio

[![CircleCI](https://circleci.com/gh/u-root/uio.svg?style=svg)](https://circleci.com/gh/u-root/uio)
[![Go Report Card](https://goreportcard.com/badge/github.com/u-root/uio)](https://goreportcard.com/report/github.com/u-root/uio)
[![GoDoc](https://godoc.org/github.com/u-root/uio?status.svg)](https://godoc.org/github.com/u-root/uio)
[![Slack](https://slack.osfw.dev/badge.svg)](https://slack.osfw.dev)
[![License](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](https://github.com/u-root/uio/blob/main/LICENSE)
